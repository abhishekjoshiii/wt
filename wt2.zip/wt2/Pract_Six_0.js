// Create an application to establish a connection with the MySql
//  database and perform basic database operations on it

var mysql = require ('mysql');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "student_inf"
});
con.connect(function (err) {
    if(err) throw  err;
    con.query("select * from emp_inf", function (err,result) {
        if(err) throw err;
        console.log(result);
      })
  });