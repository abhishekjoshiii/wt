var express = require("express");
var app     = express();
var path    = require("path");
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(express.static(__dirname + '/public'));
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "student_inf"
});
app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/index.html'));
});
app.post('/submit', function(req,res){
  var serch = req.body.search;
  con.connect(function(err) {
    if (err) throw err;
    var sql = "DELETE FROM `emp_inf` WHERE ID='"+serch+"'";
    con.query(sql, function (err, result) {
      if (err) throw err;
      
    });
  });
})


app.post('/submit',function(req,res){
  var email=req.body.email;
  var password=req.body.password;
  var addressOne=req.body.addOne;
  var addressTwo=req.body.addTwo;
  var city=req.body.city;
  var state=req.body.state;
  var zip=req.body.zip;
  con.connect(function(err) {
  if (err) throw err;
  var sql = "INSERT INTO emp_inf (email,pass,addOne,addTwo,city,state,zip) VALUES ('"+email+"','"+password+"','"+addressOne+"','"+addressTwo+"','"+city+"','"+state+"','"+zip+"')";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
     res.end();
    });
  });
})

app.listen(3000);



// app.post('/submit', function(req,res){

//   var serch = req.body.search;

//   var email=req.body.email;
//   var password=req.body.password;
//   var addressOne=req.body.addOne;
//   var addressTwo=req.body.addTwo;
//   var city=req.body.city;
//   var state=req.body.state;
//   var zip=req.body.zip;

//   con.connect(function(err) {
//     if (err) throw err;
//     var sql = "UPDATE emp_inf SET email = '"+email+"', pass='"+password+"', addOne='"+addressOne+"', addTwo='"+addressTwo+"', city='"+city+"', state='"+state+"', zip='"+zip+"' WHERE ID='"+serch+"' ";
//     con.query(sql, function (err, result) {
//       if (err) throw err;
//     });
//   });
// })