//Using File Handling demonstrate all basic file Operation(Create, Write, Read, Delete)

var http = require('http');
var fs = require('fs');
http.createServer(function(req,res){
    var txt="Hello this is file handling practical";
    fs.writeFile('index.html', txt,function(err){
        if(err) throw err;
        console.log('File Saved');
    });
    fs.open('Index.html','a', function(err, fd){
        fs.appendFile(fd, 'This is appended text', function(err){
            if(err)throw err;
            fs.close(fd, function (err) {
                if(err) throw err;
              });
        });
    })
    fs.readFile('index.html', function (err, data) {
        if(err) throw err;
        res.setHeader('200', {
            'Content-Type' : 'text/html'
        });
        res.write(data);
        res.end();
      })
}).listen(8090);