//Create an Http Server and perform operation on it

var http = require('http');
http.createServer(function (req,res) {
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    res.write('Node.js says Hello!');
    res.end();
  }).listen(8090);