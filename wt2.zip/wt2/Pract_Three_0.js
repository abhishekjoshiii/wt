var http=require('http');
var fs = require('fs');
http.createServer(function(req,res){
    var c = "";
    var reader1 = fs.createReadStream('demofile.txt');
    reader1.on('error', function(error){
        console.log(err);
    }).on('data', function (chunk) {
        c += chunk;
      }).on('end',function(){
        res.setHeader('200', {
            'Content-Type' : 'plain/text'
        });
        res.write(c);
        res.end();
      })
}).listen(8090);